﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using MySql.Data.MySqlClient;

namespace CustomerService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class CustomerService : ICustomerService
    {
        public List<Customer> GetCustomers()
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(GetConnectionString()))
                {
                    connection.Open();

                    string query = "Select * from customers";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dataReader = cmd.ExecuteReader();

                    List<Customer> customers = new List<Customer>();
                    while (dataReader.Read())
                    {
                        customers.Add(new Customer { Code = dataReader["Code"].ToString(), Name = dataReader["Name"].ToString(), Address = dataReader["Address"].ToString(), Gender = dataReader["Gender"].ToString(), PhoneNumber = dataReader["Phone"].ToString() });
                    }
                    dataReader.Close();
                    connection.Close();
                    return customers;
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }

        }
        public Customer GetCustomer(string code)
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(GetConnectionString()))
                {
                    connection.Open();

                    string query = "Select * from customers where Code='" + code + "'";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dataReader = cmd.ExecuteReader();

                    //List<Customer> customers = new List<Customer>();
                    //while (dataReader.Read())
                    //{
                    //    customers.Add(new Customer { Code = dataReader["Code"].ToString(), Name = dataReader["Name"].ToString(), Address = dataReader["Address"].ToString(), Gender = dataReader["Gender"].ToString(), PhoneNumber = dataReader["Phone"].ToString() });
                    //}

                    dataReader.Read();
                    
                    Customer foundCustomer = new Customer { Code = dataReader["Code"].ToString(), Name = dataReader["Name"].ToString(), Address = dataReader["Address"].ToString(), Gender = dataReader["Gender"].ToString(), PhoneNumber = dataReader["Phone"].ToString() };
                    
                    dataReader.Close();
                    connection.Close();
                    return foundCustomer;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }

        }

        public string DeleteCustomer(string code)
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(GetConnectionString()))
                {
                    connection.Open();

                    string query = "delete from customers where code='" + code + "'";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    int result = cmd.ExecuteNonQuery();

                    connection.Close();
                    if (result == 1) { return "Deleted customer with code " + code + " successfully"; }
                    else { return "Deleted customer with code " + code + " not found"; }

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string InsertCustomer(string customer)
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(GetConnectionString()))
                {
                    connection.Open();

                    string[] customerValues = customer.Split('|');
                    string query = "INSERT INTO customers (`Code`, `Name`, `Gender`, `Address`, `Phone`) VALUES ('" + customerValues[0] + "','" + customerValues[1] + "','" + customerValues[2] + "','" + customerValues[3] + "','" + customerValues[4] + "');";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    int result = cmd.ExecuteNonQuery();

                    connection.Close();
                    if (result == 1) { return "Customer with Code :" + customerValues[0] + " created successfully"; }
                    else { return "Customer creation failed."; }

                }
            }
            catch(Exception ex)
            {
                return ex.Message;
            }

        }

        public string UpdateCustomer(string customer)
        {
           
        try
            {
                using (MySqlConnection connection = new MySqlConnection(GetConnectionString()))
                {
                    connection.Open();

                    string[] customerValues = customer.Split('|');
                    string query = "UPDATE customers SET `Name`='"+customerValues[1]+"', `Gender`='"+customerValues[2]+"', `Address`='"+customerValues[3]+"', `Phone`='"+customerValues[4]+"' WHERE `Code`= '" + customerValues[0] + "';";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    int result = cmd.ExecuteNonQuery();

                    connection.Close();
                    if (result == 1) { return "Customer with Code :" + customerValues[0] + " updated successfully"; }
                    else { return "Customer update failed."; }

                }
            }
            catch(Exception ex)
            {
                return ex.Message;
            }

        }
        private string GetConnectionString()
        {
            string connectionString = "SERVER=localhost; DATABASE=test; UID=root;PASSWORD=tiger;";

            return connectionString;
        }
    }
}
