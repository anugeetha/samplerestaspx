﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace CustomerService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface ICustomerService
    {

        [OperationContract]
        [WebInvoke(Method="GET", ResponseFormat=WebMessageFormat.Xml, BodyStyle=WebMessageBodyStyle.Wrapped,UriTemplate="customers")]
        List<Customer> GetCustomers();

        [OperationContract]
        [WebInvoke(Method="POST",ResponseFormat = WebMessageFormat.Xml, BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "delete/{code}")]
        string DeleteCustomer(string code);

        [OperationContract]
        [WebInvoke(Method="POST",ResponseFormat = WebMessageFormat.Xml, BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "create/{customer}")]
        string InsertCustomer(string customer);

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Xml, BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "UpdateCustomer/{customer}")]
        string UpdateCustomer(string customer);

        [OperationContract]
        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Xml, BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "Getcustomer/{code}")]
        Customer GetCustomer(string code);

    }

    [DataContract]
    public class Customer
    {
        [DataMember(Order=0)]
        public string Code { get; set; }

        [DataMember(Order = 1)]
        public string Name { get; set; }

        [DataMember(Order = 2)]
        public string Gender { get; set; }

        [DataMember(Order = 3)]
        public string Address { get; set; }

        [DataMember(Order = 4)]
        public string PhoneNumber { get; set; }
    }
}
