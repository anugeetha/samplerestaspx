﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Linq;

namespace CustomerWebApp
{
    public partial class CustomerPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(TextBox1.Text))
            {
                ClientScript.RegisterStartupScript(this.GetType(), "Delete", "alert('Please enter the customer code');", true);
                return;
            }

            string strURL = "http://localhost:52751/CustomerService.svc/delete/" + TextBox1.Text;
            

            HttpWebRequest POSTRequest = (HttpWebRequest)WebRequest.Create(strURL);
            //Method type
            POSTRequest.Method = "POST";
            // Data type - message body coming in xml
            POSTRequest.ContentType = "text/xml";
            POSTRequest.KeepAlive = false;
            POSTRequest.Timeout = 5000;

            // Get the request stream
            Stream POSTstream = POSTRequest.GetRequestStream();

            //Get response from server
            HttpWebResponse POSTResponse = (HttpWebResponse)POSTRequest.GetResponse();
            StreamReader reader =
              new StreamReader(POSTResponse.GetResponseStream(), Encoding.UTF8);

            XDocument xmlDoc = XDocument.Parse(reader.ReadToEnd());
            string result = xmlDoc.Root.Value;
            result = result.Replace("'", "");

            ClientScript.RegisterStartupScript(this.GetType(), "Delete", "alert('" + result + "');", true);
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {
            bool isCodeEmpty = false;
            if (string.IsNullOrWhiteSpace(txtCode.Text))
                isCodeEmpty = true;

            bool isNameEmpty = false;
            if (string.IsNullOrWhiteSpace(txtName.Text))
                isNameEmpty = true;

            bool isGenderEmpty = false;
            if (string.IsNullOrWhiteSpace(txtGender.Text))
                isCodeEmpty = true;

            if (isCodeEmpty || isNameEmpty || isGenderEmpty)
            {
                string message = "Please enter valid " + (isCodeEmpty ? "Code, " : string.Empty) + (isNameEmpty ? "Name, " : string.Empty) + (isGenderEmpty ? "Gender " : string.Empty);

                ClientScript.RegisterStartupScript(this.GetType(), "Create", "alert('" + message + "');", true);
                return;
            }

            string strURL = string.Format("http://localhost:52751/CustomerService.svc/create/{0}|{1}|{2}|{3}|{4}", txtCode.Text, txtName.Text, txtGender.Text, txtAddress.Text, txtPhone.Text) ;


            HttpWebRequest POSTRequest = (HttpWebRequest)WebRequest.Create(strURL);
            //Method type
            POSTRequest.Method = "POST";
            // Data type - message body coming in xml
            POSTRequest.ContentType = "text/xml";
            POSTRequest.KeepAlive = false;
            POSTRequest.Timeout = 5000;

            // Get the request stream
            Stream POSTstream = POSTRequest.GetRequestStream();

            //Get response from server
            HttpWebResponse POSTResponse = (HttpWebResponse)POSTRequest.GetResponse();
            StreamReader reader =
              new StreamReader(POSTResponse.GetResponseStream(), Encoding.UTF8);

            XDocument xmlDoc = XDocument.Parse(reader.ReadToEnd());
            string result = xmlDoc.Root.Value;

            result = result.Replace("'", "");
            ClientScript.RegisterStartupScript(this.GetType(), "Delete", "alert('" + result + "');", true);


        }

        //getall
        protected void Button2_Click(object sender, EventArgs e)
        {
            lstbxCustomers.Items.Clear();
            string url = "http://localhost:52751/CustomerService.svc/customers";
            HttpWebRequest GETRequest = (HttpWebRequest)WebRequest.Create(url);
            GETRequest.Method = "GET";

            HttpWebResponse GETResponse = (HttpWebResponse)GETRequest.GetResponse();
            Stream GETResponseStream = GETResponse.GetResponseStream();
            StreamReader reader = new StreamReader(GETResponseStream);

            XmlDocument xmlDoc = new XmlDocument();

            xmlDoc.LoadXml(reader.ReadToEnd());
            XmlNodeList customers = xmlDoc.GetElementsByTagName("a:Customer");

            List<ListItem> customerList = new List<ListItem>();
            foreach(XmlNode customer in customers)
            {
                string customerDetails = string.Empty;
                foreach (XmlNode customerDetail in customer.ChildNodes)
                {
                    customerDetails += customerDetail.InnerText + ",";
                }
                customerList.Add(new ListItem { Text = customerDetails, Value = customerDetails });
            }

            lstbxCustomers.Items.AddRange(customerList.ToArray());
        }

        //update
        protected void Button4_Click(object sender, EventArgs e)
        {
            bool isCodeEmpty = false;
            if (string.IsNullOrWhiteSpace(txtCode.Text))
                isCodeEmpty = true;

            bool isNameEmpty = false;
            if (string.IsNullOrWhiteSpace(txtName.Text))
                isNameEmpty = true;

            bool isGenderEmpty = false;
            if (string.IsNullOrWhiteSpace(txtGender.Text))
                isCodeEmpty = true;

            if (isCodeEmpty || isNameEmpty || isGenderEmpty)
            {
                string message = "Please enter valid " + (isCodeEmpty ? "Code, " : string.Empty) + (isNameEmpty ? "Name, " : string.Empty) + (isGenderEmpty ? "Gender " : string.Empty);

                ClientScript.RegisterStartupScript(this.GetType(), "Create", "alert('" + message + "');", true);
                return;
            }

            string strURL = string.Format("http://localhost:52751/CustomerService.svc/UpdateCustomer/{0}|{1}|{2}|{3}|{4}", txtCode.Text, txtName.Text, txtGender.Text, txtAddress.Text, txtPhone.Text);


            HttpWebRequest POSTRequest = (HttpWebRequest)WebRequest.Create(strURL);
            //Method type
            POSTRequest.Method = "POST";
            // Data type - message body coming in xml
            POSTRequest.ContentType = "text/xml";
            POSTRequest.KeepAlive = false;
            POSTRequest.Timeout = 5000;

            // Get the request stream
            Stream POSTstream = POSTRequest.GetRequestStream();

            //Get response from server
            HttpWebResponse POSTResponse = (HttpWebResponse)POSTRequest.GetResponse();
            StreamReader reader =
              new StreamReader(POSTResponse.GetResponseStream(), Encoding.UTF8);

            XDocument xmlDoc = XDocument.Parse(reader.ReadToEnd());
            string result = xmlDoc.Root.Value;

            result = result.Replace("'", "");
            ClientScript.RegisterStartupScript(this.GetType(), "Delete", "alert('" + result + "');", true);




        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCode.Text))
            {
                ClientScript.RegisterStartupScript(this.GetType(), "Delete", "alert('Please enter the customer code');", true);
                return;
            }

            string strURL = "http://localhost:52751/CustomerService.svc/GetCustomer/" + txtCode.Text;

            HttpWebRequest GETRequest = (HttpWebRequest)WebRequest.Create(strURL);
            GETRequest.Method = "GET";

            HttpWebResponse GETResponse = (HttpWebResponse)GETRequest.GetResponse();
            Stream GETResponseStream = GETResponse.GetResponseStream();
            StreamReader reader = new StreamReader(GETResponseStream);

            XmlDocument xmlDoc = new XmlDocument();

            xmlDoc.LoadXml(reader.ReadToEnd());
           // XmlNodeList customers 
            txtCode.Text=(xmlDoc.GetElementsByTagName("a:Code"))[0].InnerText;
            txtName.Text = (xmlDoc.GetElementsByTagName("a:Name"))[0].InnerText;
            txtGender.Text = (xmlDoc.GetElementsByTagName("a:Gender"))[0].InnerText;
            txtPhone.Text = (xmlDoc.GetElementsByTagName("a:PhoneNumber"))[0].InnerText;
            txtAddress.Text = (xmlDoc.GetElementsByTagName("a:Address"))[0].InnerText;
            
        }
    }
}